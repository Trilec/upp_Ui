#include "DesignerCodeGen.h"
#include "DesignerDefaults.h"

// DesignerCodeGen.cpp - converts the model tree into standalone U++ code.
// Generated output should be theme-first: emit layout/control API calls and
// only include explicit appearance when the caller requests designer metadata.

namespace Upp {

static Value CodeGenNodeProperty(const DesignerNode& n, const String& key, const Value& def)
{
	int q = n.properties.Find(key);
	return q >= 0 ? n.properties.GetValue(q) : def;
}

static bool CodeGenHasProperty(const DesignerNode& n, const String& key)
{
	return n.properties.Find(key) >= 0;
}

static String CppString(const String& s)
{
	String out = "\"";
	for(int i = 0; i < s.GetCount(); i++) {
		byte c = s[i];
		if(c == '\\')
			out << "\\\\";
		else if(c == '"')
			out << "\\\"";
		else if(c == '\n')
			out << "\\n";
		else if(c == '\r')
			out << "\\r";
		else if(c == '\t')
			out << "\\t";
		else
			out.Cat(c);
	}
	out << "\"";
	return out;
}

static String VarName(DesignerNodeId id)
{
	return "node" + AsString(id);
}

static String CodeIdentifier(String text)
{
	text = TrimBoth(text);
	String out;
	bool last_us = false;
	for(int i = 0; i < text.GetCount(); i++) {
		int c = text[i];
		bool ok = IsAlNum(c) || c == '_';
		if(ok) {
			if(out.IsEmpty() && IsDigit(c))
				out << '_';
			out.Cat(c);
			last_us = false;
		}
		else if(!last_us && !out.IsEmpty()) {
			out << '_';
			last_us = true;
		}
	}
	while(out.GetCount() && out[out.GetCount() - 1] == '_')
		out.Trim(out.GetCount() - 1);
	if(out.IsEmpty())
		out = "node";
	static const char *reserved[] = {
		"class", "private", "public", "protected", "template", "typename", "operator",
		"int", "double", "float", "bool", "char", "void", "auto", "return", "new", "delete"
	};
	for(const char *r : reserved)
		if(out == r)
			return "_" + out;
	return out;
}

static bool NameUsed(const VectorMap<DesignerNodeId, String>& names, const String& name)
{
	for(int i = 0; i < names.GetCount(); i++)
		if(names[i] == name)
			return true;
	return false;
}

static VectorMap<DesignerNodeId, String> BuildCodeNames(const DesignerModel& model)
{
	VectorMap<DesignerNodeId, String> names;
	for(const DesignerNode& n : model.GetNodes()) {
		if(n.id == Designer_ROOT)
			continue;
		String root = CodeIdentifier(n.name);
		String name = root;
		int suffix = 2;
		while(NameUsed(names, name))
			name = Format("%s_%02d", root, suffix++);
		names.Add(n.id, name);
	}
	return names;
}

static String VarName(const VectorMap<DesignerNodeId, String>& names, DesignerNodeId id)
{
	int q = names.Find(id);
	return q >= 0 ? names[q] : VarName(id);
}

static String DirectionExpr(const DesignerNode& n, const String& def)
{
	return CodeGenNodeProperty(n, "direction", def) == "H" ? "UiDirection::H" : "UiDirection::V";
}

static String AlignSideExpr(const String& side, const String& def = "Left")
{
	String s = side.IsEmpty() ? def : side;
	if(s == "Right")
		return "UiAlign::RIGHT";
	if(s == "Top")
		return "UiAlign::TOP";
	if(s == "Bottom")
		return "UiAlign::BOTTOM";
	return "UiAlign::LEFT";
}

static String TabVisualExpr(const String& visual)
{
	if(visual == "Classic")
		return "UITAB_CLASSIC";
	if(visual == "Document")
		return "UITAB_DOCUMENT";
	if(visual == "Segmented")
		return "UITAB_SEGMENTED";
	if(visual == "Rail")
		return "UITAB_RAIL";
	return "UITAB_UNDERLINE";
}

static String GroupHeaderModeExpr(const String& mode)
{
	if(mode == "Outside")
		return "UiGroupPanel::Outside";
	if(mode == "Center")
		return "UiGroupPanel::Center";
	return "UiGroupPanel::Inside";
}

static String RoleExpr(const String& role)
{
	if(role == "Subtle")
		return "UiRole::Subtle";
	if(role == "Accent")
		return "UiRole::Accent";
	if(role == "Alert")
		return "UiRole::Alert";
	return "UiRole::Standard";
}

static String ColorExpr(Color c);

static int CodeGenBreadcrumbCount(const DesignerNode& n)
{
	return max(1, min(24, (int)CodeGenNodeProperty(n, "crumb_count", 3)));
}

static String CodeGenBreadcrumbCrumbKey(int i)
{
	return Format("crumb_%d", i + 1);
}

static String CodeGenBreadcrumbCrumbText(const DesignerNode& n, int i)
{
	String key = CodeGenBreadcrumbCrumbKey(i);
	if(CodeGenHasProperty(n, key))
		return CodeGenNodeProperty(n, key, Format("Crumb %d", i + 1));
	if(i == 0)
		return CodeGenNodeProperty(n, "crumb_a", "Home");
	if(i == 1)
		return CodeGenNodeProperty(n, "crumb_b", "Library");
	if(i == 2)
		return CodeGenNodeProperty(n, "crumb_c", "Current");
	return Format("Crumb %d", i + 1);
}

static String StyleTypeExpr(const DesignerNode& n)
{
	if(n.type_id == "UiPanel" || n.type_id == "Item" || n.type_id == "Generic")
		return "UiPanel::Style";
	if(n.type_id == "UiScrollPanel")
		return "UiScrollPanel::Style";
	if(n.type_id == "UiGroupPanel")
		return "UiGroupPanel::Style";
	if(n.type_id == "UiLabel")
		return "UiLabel::Style";
	if(n.type_id == "UiTitleCard")
		return "UiTitleCard::Style";
	if(n.type_id == "UiButton")
		return "UiButton::Style";
	if(n.type_id == "UiToolButton")
		return "UiToolButton::Style";
	if(n.type_id == "UiAccordion")
		return "UiAccordion::Style";
	if(n.type_id == "UiLineEdit" || n.type_id == "UiIntEdit" || n.type_id == "UiFloatEdit")
		return "UiBaseEdit::Style";
	if(n.type_id == "UiDropdown")
		return "UiDropdown::Style";
	if(n.type_id == "UiBreadcrumbs")
		return "UiBreadcrumbs::Style";
	return String();
}

static String ResolveStyleExpr(const DesignerNode& n, const String& role_expr)
{
	if(n.type_id == "UiPanel" || n.type_id == "Item" || n.type_id == "Generic")
		return "UiTheme::ResolvePanel(" + role_expr + ")";
	if(n.type_id == "UiScrollPanel")
		return "UiScrollPanel::StyleDefault()";
	if(n.type_id == "UiGroupPanel")
		return "UiTheme::ResolveGroupPanel(" + role_expr + ")";
	if(n.type_id == "UiLabel")
		return "UiTheme::ResolveLabel(" + role_expr + ")";
	if(n.type_id == "UiTitleCard")
		return "UiTheme::ResolveTitleCard(" + role_expr + ")";
	if(n.type_id == "UiButton")
		return "UiTheme::ResolveButton(" + role_expr + ")";
	if(n.type_id == "UiToolButton")
		return "UiTheme::ResolveToolButton(" + role_expr + ")";
	if(n.type_id == "UiAccordion")
		return "UiAccordion::StyleDefault()";
	if(n.type_id == "UiLineEdit" || n.type_id == "UiIntEdit" || n.type_id == "UiFloatEdit")
		return "UiTheme::ResolveEdit(" + role_expr + ")";
	if(n.type_id == "UiDropdown")
		return "UiTheme::ResolveDropdown(" + role_expr + ")";
	if(n.type_id == "UiBreadcrumbs")
		return "UiBreadcrumbs::StyleDefault()";
	return String();
}

static String ShadowCurveExpr(const String& curve)
{
	if(curve == "Linear")
		return "ShadowLinear()";
	if(curve == "Tight")
		return "ShadowTight()";
	if(curve == "Hard")
		return "ShadowHardCurve()";
	return "ShadowSoft()";
}

static void EmitThemeStyle(String& out, const String& var, const DesignerNode& n, bool emit_designer_appearance)
{
	String role = CodeGenNodeProperty(n, "role", "Standard");
	String role_expr = RoleExpr(role);
	String style_type = StyleTypeExpr(n);
	String resolve_expr = ResolveStyleExpr(n, role_expr);
	if(style_type.IsEmpty() || resolve_expr.IsEmpty())
		return;
	bool override = emit_designer_appearance && (bool)CodeGenNodeProperty(n, "theme_override", false);
	if(!override) {
		if(n.type_id == "UiAccordion")
			return;
		if(role != "Standard" && n.type_id != "UiScrollPanel")
			out << "\t\t" << var << ".SetCustomStyle(" << resolve_expr << ");\n";
		return;
	}

	out << "\t\t{\n"
	    << "\t\t\t" << style_type << " s = " << resolve_expr << ";\n";
	if(CodeGenHasProperty(n, "face_enabled")) {
		bool face_enabled = (bool)CodeGenNodeProperty(n, "face_enabled", false);
		out << "\t\t\ts.metrics.face_enabled = " << (face_enabled ? "true" : "false") << ";\n";
		if(face_enabled) {
			Color face = CodeGenNodeProperty(n, "face", SColorFace());
			if(CodeGenNodeProperty(n, "face_mode", "Solid") == "Quad") {
				out << "\t\t\tUiFill face_fill = UiFill::ImageFill(MakeQuadGradientTile(48, "
				    << ColorExpr(CodeGenNodeProperty(n, "face_tl", face)) << ", "
				    << ColorExpr(CodeGenNodeProperty(n, "face_tr", face)) << ", "
				    << ColorExpr(CodeGenNodeProperty(n, "face_bl", face)) << ", "
				    << ColorExpr(CodeGenNodeProperty(n, "face_br", face)) << ", 0));\n"
				    << "\t\t\tfor(int i = 0; i < 4; i++)\n"
				    << "\t\t\t\ts.palette.face[i] = face_fill;\n";
			}
			else {
				out << "\t\t\tColor face = " << ColorExpr(face) << ";\n"
				    << "\t\t\ts.palette.face[ST_NORMAL] = UiFill::Solid(face);\n"
				    << "\t\t\ts.palette.face[ST_HOT] = UiFill::Solid(Blend(face, White(), 24));\n"
				    << "\t\t\ts.palette.face[ST_PRESSED] = UiFill::Solid(Blend(face, Black(), 16));\n"
				    << "\t\t\ts.palette.face[ST_DISABLED] = UiFill::Solid(Blend(face, SColorFace(), 90));\n";
			}
		}
	}
	if(CodeGenHasProperty(n, "frame_enabled")) {
		bool frame_enabled = (bool)CodeGenNodeProperty(n, "frame_enabled", false);
		out << "\t\t\ts.metrics.frame_enabled = " << (frame_enabled ? "true" : "false") << ";\n";
		if(frame_enabled) {
			Color frame = CodeGenNodeProperty(n, "frame", SColorShadow());
			out << "\t\t\tfor(int i = 0; i < 4; i++)\n"
			    << "\t\t\t\ts.palette.frame[i] = " << ColorExpr(frame) << ";\n"
			    << "\t\t\ts.metrics.frame_width = max(DPI(1), s.metrics.frame_width);\n";
		}
	}
	if(CodeGenHasProperty(n, "radius"))
		out << "\t\t\ts.metrics.radius = DPI(" << max(0, (int)CodeGenNodeProperty(n, "radius", 0)) << ");\n";
	if(CodeGenHasProperty(n, "shadow_enabled")) {
		bool shadow = (bool)CodeGenNodeProperty(n, "shadow_enabled", false);
		out << "\t\t\ts.metrics.shadow.enabled = " << (shadow ? "true" : "false") << ";\n";
		if(shadow) {
			out << "\t\t\ts.metrics.shadow.distance = DPI(" << max(0, (int)CodeGenNodeProperty(n, "shadow_distance", 6)) << ");\n"
			    << "\t\t\ts.metrics.shadow.offset_x = DPI(" << (int)CodeGenNodeProperty(n, "shadow_offset_x", 0) << ");\n"
			    << "\t\t\ts.metrics.shadow.offset_y = DPI(" << (int)CodeGenNodeProperty(n, "shadow_offset_y", 0) << ");\n"
			    << "\t\t\ts.metrics.shadow.alpha = " << minmax((int)CodeGenNodeProperty(n, "shadow_alpha", 90), 0, 255) << ";\n"
			    << "\t\t\ts.metrics.shadow.color = " << ColorExpr(CodeGenNodeProperty(n, "shadow_color", Black())) << ";\n"
			    << "\t\t\ts.metrics.shadow.mode = SHADOW_CURVE;\n"
			    << "\t\t\ts.metrics.shadow.curve = " << ShadowCurveExpr(CodeGenNodeProperty(n, "shadow_curve", "Soft")) << ";\n";
		}
	}
	out << "\t\t\t" << var << ".SetCustomStyle(s);\n"
	    << "\t\t}\n";
}

static String FontExpr(const String& family, int size)
{
	int z = max(7, size);
	if(family == "Mono")
		return Format("MonospaceZ(%d)", z);
	if(family == "Serif")
		return Format("SerifZ(%d)", z);
	if(family == "Segoe UI" || family == "Arial" || family == "Verdana" ||
	   family == "Tahoma" || family == "Consolas")
		return Format("Font().FaceName(%s).Height(%d)", CppString(family), z);
	return Format("SansSerifZ(%d)", z);
}

static String ColorExpr(Color c)
{
	if(IsNull(c))
		return "Null";
	return Format("Color(%d, %d, %d)", c.GetR(), c.GetG(), c.GetB());
}

static Color CodeGenDebugColor(const DesignerNode& n)
{
	if(!(bool)CodeGenNodeProperty(n, "debug_auto_color", false)) {
		Value v = CodeGenNodeProperty(n, "debug_color", Color(220, 38, 38));
		return IsNull(v) ? Color(220, 38, 38) : (Color)v;
	}
	static const Color palette[] = {
		Color(220, 38, 38), Color(217, 119, 6), Color(37, 99, 235),
		Color(22, 163, 74), Color(147, 51, 234), Color(8, 145, 178),
		Color(219, 39, 119)
	};
	return palette[abs((int)n.id) % (int)(sizeof(palette) / sizeof(palette[0]))];
}

static String IconExpr(const String& icon)
{
	if(icon == "None")
		return String();
	const Vector<UiIconCatalogEntry>& catalog = UiIconCatalog();
	for(int i = 0; i < catalog.GetCount(); i++)
		if(icon == catalog[i].name)
			return icon + "()";
	if(icon == "Home") return "ICON_DESIGN_HOME_48()";
	if(icon == "Settings") return "ICON_DESIGN_SETTINGS_48()";
	if(icon == "Menu") return "ICON_DESIGN_MENU_48()";
	if(icon == "Search") return "ICON_ACTION_SEARCH_48()";
	if(icon == "Add") return "ICON_CONTENT_OUTLINED_ADD_48()";
	if(icon == "Check") return "ICON_ACTION_CHECK_CIRCLE_48()";
	if(icon == "Folder") return "ICON_DESIGN_FOLDER_48()";
	if(icon == "Image") return "ICON_DESIGN_IMAGE_48()";
	return String();
}

static void EmitDeclaration(String& out, const VectorMap<DesignerNodeId, String>& names, const DesignerNode& n)
{
	String var = VarName(names, n.id);
	if(n.type_id == "BoxLayout")
		out << "\tUiBoxLayout " << var << ";\n";
	else if(n.type_id == "GridLayout")
		out << "\tUiGridLayout " << var << ";\n";
	else if(n.type_id == "UiSplitter")
		out << "\tUiSplitter " << var << ";\n";
	else if(n.type_id == "UiQuadSplitter")
		out << "\tUiQuadSplitter " << var << ";\n";
	else if(n.type_id == "UiLabel")
		out << "\tUiLabel " << var << ";\n";
	else if(n.type_id == "UiTitleCard")
		out << "\tUiTitleCard " << var << ";\n";
	else if(n.type_id == "UiGroupPanel")
		out << "\tUiGroupPanel " << var << ";\n";
	else if(n.type_id == "UiButton")
		out << "\tUiButton " << var << ";\n";
	else if(n.type_id == "UiToolButton")
		out << "\tUiToolButton " << var << ";\n";
	else if(n.type_id == "UiAccordion")
		out << "\tUiAccordion " << var << ";\n";
	else if(n.type_id == "UiLineEdit")
		out << "\tUiLineEdit " << var << ";\n";
	else if(n.type_id == "UiIntEdit")
		out << "\tUiIntEdit " << var << ";\n";
	else if(n.type_id == "UiFloatEdit")
		out << "\tUiFloatEdit " << var << ";\n";
	else if(n.type_id == "UiSlider")
		out << "\tUiSlider " << var << ";\n";
	else if(n.type_id == "UiToggle")
		out << "\tUiToggle " << var << ";\n";
	else if(n.type_id == "UiDropdown")
		out << "\tUiDropdown " << var << ";\n";
	else if(n.type_id == "UiCheckBox")
		out << "\tUiCheckBox " << var << ";\n";
	else if(n.type_id == "UiBreadcrumbs")
		out << "\tUiBreadcrumbs " << var << ";\n";
	else if(n.type_id == "UiTab")
		out << "\tUiTab " << var << ";\n";
	else if(n.type_id == "UiStack")
		out << "\tUiStack " << var << ";\n";
	else if(n.type_id == "UiTable")
		out << "\tUiTable " << var << ";\n";
	else if(n.type_id == "UiTree")
		out << "\tUiTree " << var << ";\n";
	else if(n.type_id == "UiScrollPanel")
		out << "\tUiScrollPanel " << var << ";\n";
	else if(n.type_id == "PaneSlot" || n.type_id == "PageSlot" || n.type_id == "AccordionSectionSlot")
		out << "\tParentCtrl " << var << ";\n";
	else if(n.type_id == "Spacer")
		return;
	else
		out << "\tUiPanel " << var << ";\n";
}

static String AxisSizing(const DesignerNode& n, const String& axis_key)
{
	return CodeGenNodeProperty(n, axis_key, "Fit");
}

static String GridItemAlignHExpr(const DesignerNode& n)
{
	String align = CodeGenNodeProperty(n, "cell_align_h", "Auto");
	if(align == "Auto")
		align = CodeGenNodeProperty(n, "align_h", CodeGenNodeProperty(n, "align", "Left"));
	if(align == "Right")
		return "UiGridLayout::Align::End";
	if(align == "Center")
		return "UiGridLayout::Align::Center";
	return "UiGridLayout::Align::Start";
}

static String GridItemAlignVExpr(const DesignerNode& n)
{
	String align = CodeGenNodeProperty(n, "cell_align_v", "Auto");
	if(align == "Auto")
		align = CodeGenNodeProperty(n, "align_v", "Top");
	if(align == "Bottom")
		return "UiGridLayout::Align::End";
	if(align == "Center")
		return "UiGridLayout::Align::Center";
	return "UiGridLayout::Align::Start";
}

static String BoxSizingCall(const DesignerNode& parent, const DesignerNode& child)
{
	bool horizontal = CodeGenNodeProperty(parent, "direction", "V") == "H";
	String sizing = AxisSizing(child, horizontal ? "h_sizing" : "v_sizing");
	if(sizing == "Fixed") {
		int v = horizontal ? DesignerClampMin((int)CodeGenNodeProperty(child, "width", DESIGNER_FIXED_FALLBACK_WIDTH))
		                   : DesignerClampMin((int)CodeGenNodeProperty(child, "height", DESIGNER_FIXED_FALLBACK_HEIGHT));
		return Format(".Fixed(DPI(%d))", v);
	}
	if(sizing == "Expand")
		return ".Expand(1)";
	return ".Fit()";
}

static void EmitSetup(String& out, const VectorMap<DesignerNodeId, String>& names,
                      const DesignerNode& n, bool emit_designer_appearance)
{
	String var = VarName(names, n.id);
	if(n.type_id == "PaneSlot" || n.type_id == "PageSlot" || n.type_id == "AccordionSectionSlot" || n.type_id == "Spacer")
		return;
	EmitThemeStyle(out, var, n, emit_designer_appearance);
	if(n.type_id == "BoxLayout") {
		String wrap = CodeGenNodeProperty(n, "wrap", "None");
		out << "\t\t" << var << ".SetDirection(" << DirectionExpr(n, "V") << ")"
		    << ".SetGap(DPI(" << (int)CodeGenNodeProperty(n, "gap_x", (int)CodeGenNodeProperty(n, "gap", 8)) << "), "
		    << "DPI(" << (int)CodeGenNodeProperty(n, "gap_y", (int)CodeGenNodeProperty(n, "gap", 8)) << "))"
		    << ".SetInset(DPI(" << (int)CodeGenNodeProperty(n, "inset", 8) << "))"
		    << ".SetWrap(" << (wrap == "Snap" ? "UiBoxWrap::Snap" : wrap == "Flow" ? "UiBoxWrap::Flow" : "UiBoxWrap::None") << ")";
		if(wrap == "Snap") {
			out << ".SetWrapSnapCount(" << max(0, (int)CodeGenNodeProperty(n, "snap_count", 0)) << ")";
			int a = max(0, (int)CodeGenNodeProperty(n, "snap_size_a", 80));
			int b = max(0, (int)CodeGenNodeProperty(n, "snap_size_b", 0));
			if(a > 0 || b > 0) {
				out << ".SetWrapSnapSizes(Vector<int>()";
				if(a > 0)
					out << " << DPI(" << a << ")";
				if(b > 0)
					out << " << DPI(" << b << ")";
				out << ")";
			}
		}
		if((bool)CodeGenNodeProperty(n, "debug", false))
			out << ".SetDebugColor(" << ColorExpr(CodeGenDebugColor(n)) << ").SetDebug(true)";
		out << ";\n";
	}
	else if(n.type_id == "GridLayout") {
		out << "\t\t" << var << ".SetGridSize("
		    << max(1, (int)CodeGenNodeProperty(n, "columns", 2)) << ", "
		    << max(1, (int)CodeGenNodeProperty(n, "rows", 2)) << ")"
		    << ".SetMinCellSize(Size(DPI(" << DesignerClampMin((int)CodeGenNodeProperty(n, "cell_width", DESIGNER_GRID_CELL_WIDTH))
		    << "), DPI(" << DesignerClampMin((int)CodeGenNodeProperty(n, "cell_height", DESIGNER_GRID_CELL_HEIGHT)) << ")))"
		    << ".SetGap(DPI(" << (int)CodeGenNodeProperty(n, "gap", 8) << "))"
		    << ".SetInset(DPI(" << (int)CodeGenNodeProperty(n, "inset", 8) << "))";
		if((bool)CodeGenNodeProperty(n, "debug", false))
			out << ".SetDebugColor(" << ColorExpr(CodeGenDebugColor(n)) << ").SetDebug(true)";
		out << ";\n";
	}
	else if(n.type_id == "UiSplitter") {
		String dir = CodeGenNodeProperty(n, "direction", "H");
		out << "\t\t" << var << "." << (dir == "V" ? "Vert" : "Horz") << "();\n";
		out << "\t\t" << var << ".SetMinPixels(0, DPI(" << (int)CodeGenNodeProperty(n, "min_a", 80) << "))"
		    << ".SetMinPixels(1, DPI(" << (int)CodeGenNodeProperty(n, "min_b", 80) << "))"
		    << ".SetSplitPercent(" << (int)CodeGenNodeProperty(n, "split_percent", 50) << ");\n";
		out << "\t\t{\n"
		    << "\t\t\tUiSplitter::Style s = UiTheme::ResolveSplitter();\n"
		    << "\t\t\ts.hit_width = DPI(" << (int)CodeGenNodeProperty(n, "hit_width", 14) << ");\n"
		    << "\t\t\ts.track_thickness = DPI(" << (int)CodeGenNodeProperty(n, "track_thickness", 2) << ");\n"
		    << "\t\t\tint track_inset = DPI(" << (int)CodeGenNodeProperty(n, "track_inset", 0) << ");\n"
		    << "\t\t\ts.track_inset = Rect(track_inset, track_inset, track_inset, track_inset);\n";
		int thumb_w = (int)CodeGenNodeProperty(n, "thumb_width", 14);
		int thumb_h = (int)CodeGenNodeProperty(n, "thumb_height", 64);
		if(dir == "V") {
			out << "\t\t\ts.thumb_main = DPI(" << thumb_w << ");\n"
			    << "\t\t\ts.thumb_cross = DPI(" << thumb_h << ");\n"
			    << "\t\t\ts.thumb_icon = ICON_NAVIGATION_OUTLINED_MORE_VERT_48();\n";
		}
		else {
			out << "\t\t\ts.thumb_main = DPI(" << thumb_h << ");\n"
			    << "\t\t\ts.thumb_cross = DPI(" << thumb_w << ");\n"
			    << "\t\t\ts.thumb_icon = ICON_NAVIGATION_OUTLINED_MORE_HORIZ_48();\n";
		}
		out << "\t\t\ts.thumb_metrics.radius = DPI(" << (int)CodeGenNodeProperty(n, "thumb_radius", 8) << ");\n"
		    << "\t\t\t" << var << ".SetCustomStyle(s);\n"
		    << "\t\t}\n";
	}
	else if(n.type_id == "UiQuadSplitter") {
		out << "\t\t" << var << ".SetSplitPercent("
		    << (int)CodeGenNodeProperty(n, "column_percent", 50) << ", "
		    << (int)CodeGenNodeProperty(n, "row_percent", 50) << ")"
		    << ".SetMinPixels(0, DPI(" << (int)CodeGenNodeProperty(n, "min_a", 60) << "))"
		    << ".SetMinPixels(1, DPI(" << (int)CodeGenNodeProperty(n, "min_b", 60) << "))"
		    << ".SetMinPixels(2, DPI(" << (int)CodeGenNodeProperty(n, "min_c", 60) << "))"
		    << ".SetMinPixels(3, DPI(" << (int)CodeGenNodeProperty(n, "min_d", 60) << "));\n";
	}
	else if(n.type_id == "UiLabel") {
		out << "\t\t" << var << ".SetText(" << CppString(CodeGenNodeProperty(n, "text", n.name)) << ");\n";
		out << "\t\t" << var << ".SetContentGap(DPI(" << max(0, (int)CodeGenNodeProperty(n, "content_gap", 6)) << "));\n";
		String icon = IconExpr(CodeGenNodeProperty(n, "icon", "None"));
		if(!icon.IsEmpty())
			out << "\t\t" << var << ".SetIcon(" << icon << ", UiIconRenderMode::MonoTint)"
			    << ".SetIconSize(DPI(" << (int)CodeGenNodeProperty(n, "icon_size", 18) << "), DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 18) << "));\n";
	}
	else if(n.type_id == "UiTitleCard")
	{
		out << "\t\t" << var << ".SetTitle(" << CppString(CodeGenNodeProperty(n, "text", n.name)) << ")"
		    << ".SetSubTitle(" << CppString(CodeGenNodeProperty(n, "subtitle", "")) << ");\n";
		String icon = IconExpr(CodeGenNodeProperty(n, "icon", "None"));
		if(!icon.IsEmpty())
			out << "\t\t" << var << ".SetMedia(" << icon << ", Size(DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 24) << "), DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 24) << ")));\n";
	}
	else if(n.type_id == "UiGroupPanel") {
		out << "\t\t" << var << ".SetTitle(" << CppString(CodeGenNodeProperty(n, "text", n.name)) << ")"
		    << ".SetSubTitle(" << CppString(CodeGenNodeProperty(n, "subtitle", "")) << ")"
		    << ".SetSideTitle(" << CppString(CodeGenNodeProperty(n, "side_title", "")) << ")"
		    << ".SetHeaderMode(" << GroupHeaderModeExpr(CodeGenNodeProperty(n, "header_mode", "Inside")) << ")"
		    << ".SetHeaderPlacement(" << AlignSideExpr(CodeGenNodeProperty(n, "placement", "Top"), "Top") << ")"
		    << ".SetLine(" << ((bool)CodeGenNodeProperty(n, "line", false) ? "true" : "false") << ")"
		    << ".SetHeaderBand(" << ((bool)CodeGenNodeProperty(n, "header_band", false) ? "true" : "false") << ")"
		    << ".SetLineThickness(DPI(" << (int)CodeGenNodeProperty(n, "line_thickness", 1) << "))"
		    << ".SetInset(Rect(DPI(" << (int)CodeGenNodeProperty(n, "inset", 8) << "), DPI("
		    << (int)CodeGenNodeProperty(n, "inset", 8) << "), DPI("
		    << (int)CodeGenNodeProperty(n, "inset", 8) << "), DPI("
		    << (int)CodeGenNodeProperty(n, "inset", 8) << ")))"
		    << ".SetHeaderInset(Rect(DPI(" << (int)CodeGenNodeProperty(n, "header_inset", 6) << "), DPI("
		    << (int)CodeGenNodeProperty(n, "header_inset", 6) << "), DPI("
		    << (int)CodeGenNodeProperty(n, "header_inset", 6) << "), DPI("
		    << (int)CodeGenNodeProperty(n, "header_inset", 6) << ")));\n";
		String icon = IconExpr(CodeGenNodeProperty(n, "icon", "None"));
		if(!icon.IsEmpty())
			out << "\t\t" << var << ".SetIcon(" << icon << ").SetIconSize(DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 16) << "));\n";
	}
	else if(n.type_id == "UiButton") {
		out << "\t\t" << var << ".SetText(" << CppString(CodeGenNodeProperty(n, "text", n.name)) << ");\n";
		String icon = IconExpr(CodeGenNodeProperty(n, "icon", "None"));
		if(!icon.IsEmpty())
			out << "\t\t" << var << ".SetIcon(" << icon << ").SetIconSize(DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 16) << "), DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 16) << "));\n";
	}
	else if(n.type_id == "UiToolButton") {
		out << "\t\t" << var << ".SetText(" << CppString(CodeGenNodeProperty(n, "text", "")) << ");\n";
		String icon = IconExpr(CodeGenNodeProperty(n, "icon", "None"));
		if(!icon.IsEmpty())
			out << "\t\t" << var << ".SetIcon(" << icon << ").SetIconSize(DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 20) << "), DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 20) << "));\n";
	}
	else if(n.type_id == "UiLineEdit") {
		out << "\t\t" << var << ".SetTextUtf8(" << CppString(CodeGenNodeProperty(n, "text", n.name)) << ");\n";
		String placeholder = CodeGenNodeProperty(n, "placeholder", "");
		if(!placeholder.IsEmpty())
			out << "\t\t" << var << ".SetPlaceholder(" << CppString(placeholder) << ");\n";
	}
	else if(n.type_id == "UiIntEdit") {
		out << "\t\t" << var << ".MinMax(" << (int)CodeGenNodeProperty(n, "min", 0)
		    << ", " << (int)CodeGenNodeProperty(n, "max", 100) << ")"
		    << ".Step(" << (int)CodeGenNodeProperty(n, "step", 1) << ")"
		    << ".ShowSpin(" << ((bool)CodeGenNodeProperty(n, "spin", true) ? "true" : "false") << ");\n";
		out << "\t\t" << var << ".SetValue(" << (int)CodeGenNodeProperty(n, "value", 42) << ");\n";
	}
	else if(n.type_id == "UiFloatEdit") {
		out << "\t\t" << var << ".MinMax(" << (double)CodeGenNodeProperty(n, "minf", 0.0)
		    << ", " << (double)CodeGenNodeProperty(n, "maxf", 100.0) << ")"
		    << ".Step(" << (double)CodeGenNodeProperty(n, "stepf", 0.1) << ")"
		    << ".Precision(" << (int)CodeGenNodeProperty(n, "precision", 2) << ")"
		    << ".ShowSpin(" << ((bool)CodeGenNodeProperty(n, "spin", true) ? "true" : "false") << ");\n";
		out << "\t\t" << var << ".SetValue(" << (double)CodeGenNodeProperty(n, "valuef", 3.14) << ");\n";
	}
	else if(n.type_id == "UiSlider")
		out << "\t\t" << var << ".SetRange(0, 100).SetValue(50);\n";
	else if(n.type_id == "UiToggle")
		out << "\t\t" << var << ".SetOn(" << ((bool)CodeGenNodeProperty(n, "on", true) ? "true" : "false") << ");\n";
	else if(n.type_id == "UiDropdown") {
		out << "\t\t" << var << ".UseInternalModel().Add(\"First\", \"First\").Add(\"Second\", \"Second\").Add(\"Third\", \"Third\");\n";
		out << "\t\t" << var << ".SetData(" << CppString(CodeGenNodeProperty(n, "selected", "First")) << ");\n";
	}
	else if(n.type_id == "UiCheckBox") {
		out << "\t\t" << var << ".SetText(" << CppString(CodeGenNodeProperty(n, "text", n.name)) << ")"
		    << ".SetTriState(" << ((bool)CodeGenNodeProperty(n, "tri_state", false) ? "true" : "false") << ");\n";
		String state = CodeGenNodeProperty(n, "state", "Checked");
		out << "\t\t" << var << ".SetState(" << (state == "Indeterminate" ? "UICHECK_INDETERMINATE" :
		                                       state == "Unchecked" ? "UICHECK_UNCHECKED" : "UICHECK_CHECKED") << ");\n";
	}
	else if(n.type_id == "UiBreadcrumbs") {
		int count = CodeGenBreadcrumbCount(n);
		for(int i = 0; i < count; i++)
			out << "\t\t" << var << ".AddCrumb(" << CppString(CodeGenBreadcrumbCrumbText(n, i)) << ", "
			    << CppString(AsString(i)) << ");\n";
		out << "\t\t" << var << ".SetCurrentIndex("
		    << clamp((int)CodeGenNodeProperty(n, "current", min(2, count - 1)), 0, count - 1) << ");\n";
		out << "\t\t" << var << ".SetTrimOnSelect(" << ((bool)CodeGenNodeProperty(n, "trim", false) ? "true" : "false")
		    << ").SetDivider(" << CppString(CodeGenNodeProperty(n, "divider", "/")) << ");\n";
		String divider_icon = IconExpr(CodeGenNodeProperty(n, "divider_icon", "None"));
		if(!divider_icon.IsEmpty())
			out << "\t\t" << var << ".SetDividerIcon(" << divider_icon << ", Size(DPI("
			    << (int)CodeGenNodeProperty(n, "divider_icon_size", 14) << "), DPI("
			    << (int)CodeGenNodeProperty(n, "divider_icon_size", 14) << ")));\n";
		String icon = IconExpr(CodeGenNodeProperty(n, "icon", "None"));
		if(!icon.IsEmpty())
			out << "\t\t" << var << ".SetPathIcon(" << icon << ", UiAlign::LEFT, Size(DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 16) << "), DPI("
			    << (int)CodeGenNodeProperty(n, "icon_size", 16) << ")));\n";
	}
	else if(n.type_id == "UiAccordion") {
		out << "\t\t" << var << ".SetSingleOpen(" << ((bool)CodeGenNodeProperty(n, "single_open", false) ? "true" : "false") << ")"
		    << ".SetEnforceOne(" << ((bool)CodeGenNodeProperty(n, "enforce_one", false) ? "true" : "false") << ")"
		    << ".ShowChevron(" << ((bool)CodeGenNodeProperty(n, "show_chevron", true) ? "true" : "false") << ")"
		    << ".SetChevronSide(" << AlignSideExpr(CodeGenNodeProperty(n, "chevron_side", "Right"), "Right") << ")"
		    << ".SetAnimation(" << ((bool)CodeGenNodeProperty(n, "animation", true) ? "true" : "false") << ", "
		    << (int)CodeGenNodeProperty(n, "open_ms", 120) << ", "
		    << (int)CodeGenNodeProperty(n, "close_ms", 0) << ")"
		    << ".ShowDragHandle(" << ((bool)CodeGenNodeProperty(n, "show_drag_handle", false) ? "true" : "false") << ")"
		    << ".EnableDragReorder(" << ((bool)CodeGenNodeProperty(n, "drag_reorder", false) ? "true" : "false") << ");\n";
	}
	else if(n.type_id == "UiTab") {
		String visual = CodeGenNodeProperty(n, "visual", "Underline");
		out << "\t\t" << var << ".SetVisual(" << TabVisualExpr(visual) << ")"
		    << ".SetPlacement(" << AlignSideExpr(CodeGenNodeProperty(n, "placement", "Top"), "Top") << ")"
		    << ".SetExpandTabs(" << ((bool)CodeGenNodeProperty(n, "expand_tabs", false) ? "true" : "false") << ")"
		    << ".EnableCloseButtons(" << ((bool)CodeGenNodeProperty(n, "close_buttons", false) ? "true" : "false") << ")"
		    << ".EnableDragHandles(" << ((bool)CodeGenNodeProperty(n, "drag_handles", false) ? "true" : "false") << ");\n";
		out << "\t\t" << var << ".SetTabFont("
		    << FontExpr(CodeGenNodeProperty(n, "tab_font", "Sans"), (int)CodeGenNodeProperty(n, "tab_font_size", 11))
		    << ").SetTabIconSize(DPI(" << (int)CodeGenNodeProperty(n, "tab_icon_size", 16) << "))"
		    << ".SetTabIconSide(" << AlignSideExpr(CodeGenNodeProperty(n, "tab_icon_side", "Left")) << ");\n";
	}
	else if(n.type_id == "UiStack") {
		// Headless page container: pages and active index are emitted after children.
	}
	else if(n.type_id == "UiTable") {
		out << "\t\t" << var << ".UseInternalModel();\n"
		    << "\t\t" << var << ".GetInternalModel().SetSize(" << (int)CodeGenNodeProperty(n, "rows_count", 4)
		    << ", " << (int)CodeGenNodeProperty(n, "cols_count", 3) << ");\n";
	}
	else if(n.type_id == "UiTree") {
		out << "\t\t" << var << ".GetInternalModel().AddChild(" << var << ".GetInternalModel().Root(), UiModelItem(\"Workspace\", \"workspace\"));\n";
		out << "\t\t" << var << ".ShowConnectorLines(" << ((bool)CodeGenNodeProperty(n, "connectors", true) ? "true" : "false") << ");\n";
	}
	else if(n.type_id == "UiScrollPanel") {
		String mode = CodeGenNodeProperty(n, "scroll_mode", "Auto");
		String expr = mode == "Vertical" ? "UIPANELSCROLL_VERTICAL" :
		              mode == "Horizontal" ? "UIPANELSCROLL_HORIZONTAL" :
		              mode == "None" ? "UIPANELSCROLL_NONE" : "UIPANELSCROLL_AUTO";
		out << "\t\t" << var << ".SetScrollMode(" << expr << ");\n";
	}
	else if(n.type_id == "UiPanel") {
		out << "\t\t" << var << ".SetSizeMin(DPI("
		    << DesignerClampMin((int)CodeGenNodeProperty(n, "min_width", DESIGNER_MIN_CLAMP))
		    << "), DPI("
		    << DesignerClampMin((int)CodeGenNodeProperty(n, "min_height", DESIGNER_MIN_CLAMP))
		    << "));\n";
	}
	else {
		out << "\t\t" << var << ".SetCustomStyle(UiTheme::ResolvePanel(UiPanelRole::Subtle));\n";
	}
}

static void EmitAddSpacer(String& out, const String& parent_var, const DesignerNode& parent,
                          const DesignerNode& child)
{
	String kind = CodeGenNodeProperty(child, "spacer_kind", "Expander");
	int size = max(0, (int)CodeGenNodeProperty(child, "space", 24));
	int max_size = max(size, (int)CodeGenNodeProperty(child, "max_space", 1000000));
	int weight = max(1, (int)CodeGenNodeProperty(child, "weight", 1));
	if(parent.type_id == "BoxLayout") {
		if(kind == "Break")
			out << "\t\t" << parent_var << ".AddBreak(" << weight << ");\n";
		else if(kind == "Fixed")
			out << "\t\t" << parent_var << ".AddSpacer(1).Fixed(DPI(" << size << "));\n";
		else
			out << "\t\t" << parent_var << ".AddSpacer(" << weight << ");\n";
	}
	else if(parent.type_id == "GridLayout") {
		if(kind == "Break")
			out << "\t\t" << parent_var << ".AddBreak();\n";
		else if(kind == "Fixed")
			out << "\t\t" << parent_var << ".AddGap(DPI(" << size << "));\n";
		else if(kind == "Bounded")
			out << "\t\t" << parent_var << ".AddSpacer(DPI(" << size << "), DPI(" << max_size << "));\n";
		else
			out << "\t\t" << parent_var << ".AddExpand(" << weight << ");\n";
	}
}

static void EmitAddChild(String& out, const VectorMap<DesignerNodeId, String>& names,
                         const DesignerNode& parent, const DesignerNode& child, int index)
{
	String p = VarName(names, parent.id);
	String c = VarName(names, child.id);
	if(child.type_id == "Spacer" && parent.id == Designer_ROOT)
		return;
	if(parent.id == Designer_ROOT)
		out << "\t\tAdd(" << c << ".SizePos());\n";
	else if(child.type_id == "Spacer" && (parent.type_id == "BoxLayout" || parent.type_id == "GridLayout"))
		EmitAddSpacer(out, p, parent, child);
	else if(parent.type_id == "BoxLayout")
		out << "\t\t" << p << ".Add(" << c << ")" << BoxSizingCall(parent, child) << ";\n";
	else if(parent.type_id == "GridLayout") {
		int columns = max(1, (int)CodeGenNodeProperty(parent, "columns", 2));
		int row = max(0, (int)CodeGenNodeProperty(child, "grid_row", index / columns));
		int col = max(0, (int)CodeGenNodeProperty(child, "grid_col", index % columns));
		String hs = AxisSizing(child, "h_sizing");
		String vs = AxisSizing(child, "v_sizing");
		if(hs == "Fixed" || vs == "Fixed") {
			int w = DesignerClampMin((int)CodeGenNodeProperty(child, "width", DESIGNER_FIXED_FALLBACK_WIDTH));
			int h = DesignerClampMin((int)CodeGenNodeProperty(child, "height", DESIGNER_FIXED_FALLBACK_HEIGHT));
			out << "\t\t{\n";
			out << "\t\t\tint item = " << p << ".Add(" << c << ", " << row << ", " << col
			    << ", " << (hs == "Expand" ? "true" : "false")
			    << ", " << (vs == "Expand" ? "true" : "false")
			    << ", Size(DPI(" << w << "), DPI(" << h << ")));\n";
			out << "\t\t\t" << p << ".SetItemAlign(item, " << GridItemAlignHExpr(child) << ", " << GridItemAlignVExpr(child) << ");\n";
			out << "\t\t}\n";
		}
		else {
			out << "\t\t{\n";
			out << "\t\t\tint item = " << p << ".Add(" << c << ", " << row << ", " << col
			    << ", " << (hs == "Expand" ? "true" : "false")
			    << ", " << (vs == "Expand" ? "true" : "false") << ");\n";
			out << "\t\t\t" << p << ".SetItemAlign(item, " << GridItemAlignHExpr(child) << ", " << GridItemAlignVExpr(child) << ");\n";
			out << "\t\t}\n";
		}
	}
	else if(parent.type_id == "UiSplitter") {
		out << "\t\t" << p << ".Add(" << c << ");\n";
		if(index == 0) {
			out << "\t\t" << p << ".SetMinPixels(0, DPI(" << (int)CodeGenNodeProperty(parent, "min_a", 80) << "));\n";
			out << "\t\t" << p << ".SetMinPixels(1, DPI(" << (int)CodeGenNodeProperty(parent, "min_b", 80) << "));\n";
		}
		out << "\t\t" << p << ".SetSplitPercent(" << (int)CodeGenNodeProperty(parent, "split_percent", 50) << ");\n";
	}
	else if(parent.type_id == "UiQuadSplitter") {
		out << "\t\t" << p << ".Add(" << c << ");\n";
		if(index == 0) {
			out << "\t\t" << p << ".SetMinPixels(0, DPI(" << (int)CodeGenNodeProperty(parent, "min_a", 60) << "));\n";
			out << "\t\t" << p << ".SetMinPixels(1, DPI(" << (int)CodeGenNodeProperty(parent, "min_b", 60) << "));\n";
			out << "\t\t" << p << ".SetMinPixels(2, DPI(" << (int)CodeGenNodeProperty(parent, "min_c", 60) << "));\n";
			out << "\t\t" << p << ".SetMinPixels(3, DPI(" << (int)CodeGenNodeProperty(parent, "min_d", 60) << "));\n";
		}
		out << "\t\t" << p << ".SetSplitPercent("
		    << (int)CodeGenNodeProperty(parent, "column_percent", 50) << ", "
		    << (int)CodeGenNodeProperty(parent, "row_percent", 50) << ");\n";
	}
	else if(parent.type_id == "UiTab") {
		String title = (bool)CodeGenNodeProperty(child, "show_title", true)
		             ? AsString(CodeGenNodeProperty(child, "page_title", child.name))
		             : String();
		String icon = IconExpr(CodeGenNodeProperty(child, "icon", "None"));
		out << "\t\t" << p << ".Add(" << c << ", " << CppString(title);
		if(!icon.IsEmpty())
			out << ", " << icon;
		out << ");\n";
	}
	else if(parent.type_id == "UiStack")
		out << "\t\t" << p << ".AddPage(" << c << ", " << CppString(CodeGenNodeProperty(child, "page_title", child.name)) << ");\n";
	else if(parent.type_id == "UiAccordion") {
        String title = child.type_id == "AccordionSectionSlot" ? AsString(CodeGenNodeProperty(child, "section_title", child.name)) : child.name;
        String subtitle = child.type_id == "AccordionSectionSlot" ? AsString(CodeGenNodeProperty(child, "section_subtitle", "")) : String();

		bool open = child.type_id == "AccordionSectionSlot" ? (bool)CodeGenNodeProperty(child, "open", true) : true;
		out << "\t\t{\n";
		out << "\t\t\tint section = " << p << ".AddSection(" << CppString(title) << ", "
		    << CppString(subtitle) << ", String(), " << (open ? "true" : "false") << ");\n";
		if(child.type_id == "AccordionSectionSlot") {
			String lock = CodeGenNodeProperty(child, "lock", "None");
			if(lock != "None")
				out << "\t\t\t" << p << ".SetLockMode(section, UiAccordion::Lock::" << lock << ");\n";
			int body_height = (int)CodeGenNodeProperty(child, "body_height", -1);
			if(body_height > 0)
				out << "\t\t\t" << p << ".SetSectionBodyHeight(section, DPI(" << body_height << "));\n";
		}
		out << "\t\t\t" << p << ".GetSectionContent(section).Add(" << c << ".SizePos());\n";
		out << "\t\t}\n";
	}
	else if(parent.type_id == "UiScrollPanel")
		out << "\t\t" << p << ".Content().Add(" << c << ".SizePos());\n";
	else if(parent.type_id == "UiGroupPanel")
		out << "\t\t" << p << ".SetContent(" << c << ");\n";
	else if(parent.type_id == "UiPanel")
		out << "\t\t" << p << ".Add(" << c << ".SizePos());\n";
	else if(parent.type_id == "PaneSlot" || parent.type_id == "PageSlot" || parent.type_id == "AccordionSectionSlot")
		out << "\t\t" << p << ".Add(" << c << ".SizePos());\n";
}

static void EmitAdds(String& out, const VectorMap<DesignerNodeId, String>& names,
                     const DesignerModel& model, const DesignerNode& parent)
{
	for(int i = 0; i < parent.children.GetCount(); i++) {
		DesignerNodeId child_id = parent.children[i];
		const DesignerNode* child = model.Find(child_id);
		if(!child)
			continue;
		EmitAddChild(out, names, parent, *child, i);
		EmitAdds(out, names, model, *child);
	}
}

static void EmitPostAddSetup(String& out, const VectorMap<DesignerNodeId, String>& names, const DesignerModel& model)
{
	for(const DesignerNode& n : model.GetNodes()) {
		String var = VarName(names, n.id);
		if(n.type_id == "UiTab")
			out << "\t\t" << var << ".SetActiveTab(" << (int)CodeGenNodeProperty(n, "active", 0) << ");\n";
		else if(n.type_id == "UiStack")
			out << "\t\t" << var << ".SetActivePage(" << (int)CodeGenNodeProperty(n, "active", 0) << ");\n";
	}
}

String GenerateDesignerCode(const DesignerModel& model, const DesignerRegistry& registry,
                              const String& class_name, bool emit_designer_appearance)
{
	(void)registry;
	VectorMap<DesignerNodeId, String> names = BuildCodeNames(model);
	String out;
	out << "#include <CtrlLib/CtrlLib.h>\n"
	    << "#include <Ui/Ui.h>\n\n"
	    << "using namespace Upp;\n\n"
	    << "class " << class_name << " : public TopWindow {\n"
	    << "public:\n"
	    << "\ttypedef " << class_name << " CLASSNAME;\n\n"
	    << "\t" << class_name << "()\n"
	    << "\t{\n"
	    << "\t\tTitle(\"Generated Designer Layout\");\n"
	    << "\t\tSizeable().Zoomable();\n";
	Size sz = model.GetVirtualSize();
	out << "\t\tSetRect(0, 0, DPI(" << sz.cx << "), DPI(" << sz.cy << "));\n"
	    << "\t\tBuild();\n"
	    << "\t}\n\n"
	    << "private:\n"
	    << "\tvoid Build()\n"
	    << "\t{\n";
	for(const DesignerNode& n : model.GetNodes()) {
		if(n.id == Designer_ROOT)
			continue;
		EmitSetup(out, names, n, emit_designer_appearance);
	}
	const DesignerNode* root = model.Find(Designer_ROOT);
	if(root)
		EmitAdds(out, names, model, *root);
	EmitPostAddSetup(out, names, model);
	out << "\t}\n\n";
	for(const DesignerNode& n : model.GetNodes()) {
		if(n.id == Designer_ROOT)
			continue;
		EmitDeclaration(out, names, n);
	}
	out << "};\n\n"
	    << "GUI_APP_MAIN\n"
	    << "{\n"
	    << "\t" << class_name << "().Run();\n"
	    << "}\n";
	return out;
}

}
