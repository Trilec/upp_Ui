from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]

def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8-sig")

def write(rel, text):
    (ROOT / rel).write_text(text, encoding="utf-8")

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, found {count}")
    return text.replace(old, new, 1)

rel = "Utilities/UiDesigner/CodeGen/UiDesignerCodeGen.cpp"
text = read(rel)
text = replace_once(
    text,
    '''    if(spec.FindProperty("content_gap"))
        out << "\\t" << member << ".SetContentGap(DPI("
            << max(0, (int)Effective("content_gap", 4)) << "));\\n";
''',
    '''    if(spec.FindProperty("content_gap") &&
       (IsButtonFamily(spec.runtime_kind) ||
        spec.runtime_kind == UiDesignerRuntimeKind::UiLabel))
        out << "\\t" << member << ".SetContentGap(DPI("
            << max(0, (int)Effective("content_gap", 4)) << "));\\n";
''',
    "CodeGen content-gap control-family guard")
write(rel, text)

rel = "Utilities/UiDesigner/Preview/UiDesignerPreview.cpp"
text = read(rel)
text = replace_once(
    text,
    '''    if(property == "content_gap") {
        if(auto *button = dynamic_cast<UiButton *>(&ctrl))
''',
    '''    if(property == "content_gap" &&
       !dynamic_cast<UiTab *>(&ctrl)) {
        if(auto *button = dynamic_cast<UiButton *>(&ctrl))
''',
    "Preview content-gap Tab fallthrough")
write(rel, text)

rel = "Utilities/UiDesigner/RegressionTests/main.cpp"
text = read(rel)
needle = '''    Check(semantic_code.Find(".GetSectionHeader(") >= 0 &&
              semantic_code.Find(".SetMedia(") >= 0,
          "Generated Accordion sections author the exposed UiTitleCard header");

'''
addition = '''    Check(semantic_code.Find(".GetSectionHeader(") >= 0 &&
              semantic_code.Find(".SetMedia(") >= 0,
          "Generated Accordion sections author the exposed UiTitleCard header");
    Check(semantic_code.Find("_tab_layout_style.content_gap = DPI(") >= 0 &&
              semantic_code.Find(".SetContentGap(DPI(") < 0,
          "Generated UiTab routes content gap through UiTab::Style only");

'''
text = replace_once(text, needle, addition, "Regression generated UiTab content-gap contract")
write(rel, text)

checks = {
    "Utilities/UiDesigner/CodeGen/UiDesignerCodeGen.cpp":
        'spec.runtime_kind == UiDesignerRuntimeKind::UiLabel))',
    "Utilities/UiDesigner/Preview/UiDesignerPreview.cpp":
        'property == "content_gap" &&\n       !dynamic_cast<UiTab *>(&ctrl)',
    "Utilities/UiDesigner/RegressionTests/main.cpp":
        "Generated UiTab routes content gap through UiTab::Style only",
}
for rel, needle in checks.items():
    if needle not in read(rel):
        raise RuntimeError(f"{rel}: missing verification text {needle!r}")

print("UiDesigner content-gap dispatch correction applied.")
