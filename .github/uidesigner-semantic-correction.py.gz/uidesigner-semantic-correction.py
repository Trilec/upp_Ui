
from pathlib import Path
import re

ROOT = Path.cwd()

def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8-sig")

def write(rel, text):
    (ROOT / rel).write_text(text, encoding="utf-8")

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, found {count}")
    return text.replace(old, new, 1)

# ---------------------------------------------------------------------------
# Catalog organiser: compile fix, inherited glyph choices, complete Tab API.
# ---------------------------------------------------------------------------
rel = "Utilities/UiDesigner/Catalog/UiDesignerInspectorCatalog.cpp"
text = read(rel)

text = replace_once(
    text,
    '''static void PopulateIconChoices(UiDesignerPropertySpec& property)
{
    property.kind = PropertyEditorKind::Choice;
    property.choices.Clear();
    property.choices.Add(PropertyEditorChoice("None", "None"));
    for(const UiIconCatalogEntry& entry : UiIconCatalog())
        property.choices.Add(PropertyEditorChoice(
            entry.name, entry.display_name,
            entry.factory ? entry.factory() : Image()));
}
''',
    '''static void PopulateIconChoices(UiDesignerPropertySpec& property)
{
    property.kind = PropertyEditorKind::Choice;
    property.choices.Clear();
    if(AsString(property.default_value) == "Default")
        property.choices.Add(PropertyEditorChoice(
            "Default", "Control default"));
    property.choices.Add(PropertyEditorChoice("None", "None"));
    for(const UiIconCatalogEntry& entry : UiIconCatalog())
        property.choices.Add(PropertyEditorChoice(
            entry.name, entry.display_name,
            entry.factory ? entry.factory() : Image()));
}
''',
    "icon catalogue inherited choice")

text = replace_once(
    text,
    '''static void EnsureIcon(UiDesignerControlSpec& spec,
                       const String& id = "icon",
                       const String& label = "Icon",
                       const String& group = "Content")
{
    UiDesignerPropertySpec* property = FindProperty(spec, id);
    if(!property) {
        AddProperty(spec, MakeIcon(id, label, group));
        property = FindProperty(spec, id);
    }
    property->group = group;
    property->domain = group == "Content" ? PropertyEditorDomain::Content
                                           : PropertyEditorDomain::Appearance;
    property->default_value = "None";
    spec.defaults.Set(id, "None");
    PopulateIconChoices(*property);
}
''',
    '''static void EnsureIcon(UiDesignerControlSpec& spec,
                       const String& id = "icon",
                       const String& label = "Icon",
                       const String& group = "Content",
                       const String& default_value = "None")
{
    UiDesignerPropertySpec* property = FindProperty(spec, id);
    if(!property) {
        AddProperty(spec, MakeIcon(id, label, group));
        property = FindProperty(spec, id);
    }
    property->group = group;
    property->domain = group == "Content" ? PropertyEditorDomain::Content
                                           : PropertyEditorDomain::Appearance;
    property->default_value = default_value;
    spec.defaults.Set(id, default_value);
    PopulateIconChoices(*property);
}
''',
    "icon catalogue default contract")

text = replace_once(
    text,
    '''    EnsureIcon(spec, "chevron_open_icon", "Open chevron", "Appearance");
    EnsureIcon(spec, "chevron_closed_icon", "Closed chevron", "Appearance");
    EnsureIcon(spec, "chevron_lock_icon", "Lock icon", "Appearance");
''',
    '''    EnsureIcon(spec, "chevron_open_icon", "Open chevron", "Appearance", "Default");
    EnsureIcon(spec, "chevron_closed_icon", "Closed chevron", "Appearance", "Default");
    EnsureIcon(spec, "chevron_lock_icon", "Lock icon", "Appearance", "Default");
''',
    "accordion inherited chevron defaults")

text = replace_once(
    text,
    '''    EnsureIcon(spec, "drag_icon", "Drag icon", "Appearance");
''',
    '''    EnsureIcon(spec, "drag_icon", "Drag icon", "Appearance", "Default");
''',
    "accordion inherited drag default")

tab_anchor = '''static void NormalizeTab(UiDesignerControlSpec& spec)
{
    const UiTab::Style& style = UiTab::StyleDefault();
'''
tab_intro = '''static void NormalizeTab(UiDesignerControlSpec& spec)
{
    const UiTab::Style& style = UiTab::StyleDefault();

    UiDesignerPropertySpec font_face = MakeText(
        "tab_font_face", "Tab font face", "Appearance",
        style.tab_font.GetFaceName());
    font_face.domain = PropertyEditorDomain::Appearance;
    font_face.impact = PropertyImpactPaint | PropertyImpactLocalLayout |
                       PropertyImpactCode;
    AddProperty(spec, pick(font_face));
    AddProperty(spec, MakeInt(
        "tab_font_size", "Tab font size", "Appearance",
        max(1, style.tab_font.GetHeight()), 1, 256));
    AddProperty(spec, MakeBool(
        "tab_font_bold", "Tab font bold", "Appearance",
        style.tab_font.IsBold(), PropertyEditorDomain::Appearance));
    AddProperty(spec, MakeBool(
        "tab_font_italic", "Tab font italic", "Appearance",
        style.tab_font.IsItalic(), PropertyEditorDomain::Appearance));
    AddProperty(spec, MakeInt(
        "tab_extent", "Tab extent", "Appearance",
        style.tab_extent / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "item_spacing", "Item spacing", "Appearance",
        style.item_spacing / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "body_gap", "Body gap", "Appearance",
        style.body_gap / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "content_gap", "Content gap", "Appearance",
        style.content_gap / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "tab_padding_left", "Tab padding left", "Appearance",
        style.tab_padding.left / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "tab_padding_top", "Tab padding top", "Appearance",
        style.tab_padding.top / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "tab_padding_right", "Tab padding right", "Appearance",
        style.tab_padding.right / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "tab_padding_bottom", "Tab padding bottom", "Appearance",
        style.tab_padding.bottom / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "strip_inset_left", "Strip inset left", "Appearance",
        style.strip_inset.left / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "strip_inset_top", "Strip inset top", "Appearance",
        style.strip_inset.top / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "strip_inset_right", "Strip inset right", "Appearance",
        style.strip_inset.right / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "strip_inset_bottom", "Strip inset bottom", "Appearance",
        style.strip_inset.bottom / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "affordance_gap", "Affordance gap", "Appearance",
        style.affordance_gap / DPI(1), 0, 1000));
    AddProperty(spec, MakeInt(
        "min_tab_main", "Minimum tab extent", "Appearance",
        style.min_tab_main / DPI(1), 0, 4000));
'''
text = replace_once(text, tab_anchor, tab_intro, "complete tab appearance contract")

text = replace_once(
    text,
    '''    Array<UiDesignerPropertySpec> source = pick(spec.properties);
''',
    '''    Vector<UiDesignerPropertySpec> source = pick(spec.properties);
''',
    "property container compile fix")

write(rel, text)

# ---------------------------------------------------------------------------
# Inspector group subtitle: use the actual selected runtime/semantic type id.
# ---------------------------------------------------------------------------
rel = "Utilities/UiDesigner/UiDesigner/UiDesignerWindow.cpp"
text = read(rel)
text = replace_once(
    text,
    '''            if(same_type) {
                const UiDesignerControlSpec* spec = session_.Catalog().Find(primary->type);
                identity = (spec ? spec->display_name : primary->type) +
                           Format(" - %d selected", selection.nodes.GetCount());
            }
''',
    '''            if(same_type)
                identity = primary->type +
                           Format(" - %d selected", selection.nodes.GetCount());
''',
    "multi-selection raw identity subtitle")
text = replace_once(
    text,
    '''        else if(primary->id != session_.Document().GetRootId()) {
            const UiDesignerControlSpec* spec = session_.Catalog().Find(primary->type);
            identity = spec ? spec->display_name : primary->type;
        }
''',
    '''        else if(primary->id != session_.Document().GetRootId())
            identity = primary->type;
''',
    "single-selection raw identity subtitle")
write(rel, text)

# ---------------------------------------------------------------------------
# Preview: preserve defaults, apply complete Tab appearance, and keep borrowed
# Accordion headers coherent after state and local-theme changes.
# ---------------------------------------------------------------------------
rel = "Utilities/UiDesigner/Preview/UiDesignerPreview.cpp"
text = read(rel)

text = replace_once(
    text,
    '''        if(property == "chevron_open_icon" || property == "chevron_closed_icon" || property == "chevron_lock_icon") {
            const UiAccordion::Style& current = accordion->GetStyle();
            accordion->SetChevronGlyphs(
                property == "chevron_open_icon" ? ResolveCatalogIcon(AsString(value)) : current.glyph_open,
                property == "chevron_closed_icon" ? ResolveCatalogIcon(AsString(value)) : current.glyph_closed,
                property == "chevron_lock_icon" ? ResolveCatalogIcon(AsString(value)) : current.glyph_lock);
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
        if(property == "drag_side") { accordion->SetDragSide(ParseSideAlignChoice(value)); return UiDesignerApplyResult::AppliedLocalLayout; }
        if(property == "drag_icon") { accordion->SetDragGlyph(ResolveCatalogIcon(AsString(value))); return UiDesignerApplyResult::AppliedLocalLayout; }
''',
    '''        if(property == "chevron_open_icon" || property == "chevron_closed_icon" || property == "chevron_lock_icon") {
            const UiAccordion::Style& current = accordion->GetStyle();
            const UiAccordion::Style& defaults = UiAccordion::StyleDefault();
            const auto ResolveGlyph = [&](const Value& choice,
                                          const Image& fallback) {
                const String name = AsString(choice);
                return name == "Default" ? fallback : ResolveCatalogIcon(name);
            };
            accordion->SetChevronGlyphs(
                property == "chevron_open_icon"
                    ? ResolveGlyph(value, defaults.glyph_open) : current.glyph_open,
                property == "chevron_closed_icon"
                    ? ResolveGlyph(value, defaults.glyph_closed) : current.glyph_closed,
                property == "chevron_lock_icon"
                    ? ResolveGlyph(value, defaults.glyph_lock) : current.glyph_lock);
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
        if(property == "drag_side") { accordion->SetDragSide(ParseSideAlignChoice(value)); return UiDesignerApplyResult::AppliedLocalLayout; }
        if(property == "drag_icon") {
            const String name = AsString(value);
            accordion->SetDragGlyph(name == "Default"
                ? UiAccordion::StyleDefault().drag_glyph
                : ResolveCatalogIcon(name));
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
''',
    "preview inherited accordion glyphs")

text = replace_once(
    text,
    '''        if(property == "drag_reorder") { tab->EnableDragReorder((bool)value); return UiDesignerApplyResult::AppliedControlState; }
    }
''',
    '''        if(property == "drag_reorder") { tab->EnableDragReorder((bool)value); return UiDesignerApplyResult::AppliedControlState; }
        if(property == "tab_font_face" || property == "tab_font_size" ||
           property == "tab_font_bold" || property == "tab_font_italic") {
            Font font = tab->GetTabFont();
            if(property == "tab_font_face") font.FaceName(AsString(value));
            else if(property == "tab_font_size") font.Height(max(1, (int)value));
            else if(property == "tab_font_bold") font.Bold((bool)value);
            else font.Italic((bool)value);
            tab->SetTabFont(font);
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
        if(property == "tab_extent" || property == "item_spacing" ||
           property == "body_gap" || property == "content_gap" ||
           property == "tab_padding_left" || property == "tab_padding_top" ||
           property == "tab_padding_right" || property == "tab_padding_bottom" ||
           property == "strip_inset_left" || property == "strip_inset_top" ||
           property == "strip_inset_right" || property == "strip_inset_bottom" ||
           property == "affordance_gap" || property == "min_tab_main") {
            UiTab::Style style = tab->GetStyle();
            const int amount = DPI(max(0, (int)value));
            if(property == "tab_extent") style.tab_extent = amount;
            else if(property == "item_spacing") style.item_spacing = amount;
            else if(property == "body_gap") style.body_gap = amount;
            else if(property == "content_gap") style.content_gap = amount;
            else if(property == "tab_padding_left") style.tab_padding.left = amount;
            else if(property == "tab_padding_top") style.tab_padding.top = amount;
            else if(property == "tab_padding_right") style.tab_padding.right = amount;
            else if(property == "tab_padding_bottom") style.tab_padding.bottom = amount;
            else if(property == "strip_inset_left") style.strip_inset.left = amount;
            else if(property == "strip_inset_top") style.strip_inset.top = amount;
            else if(property == "strip_inset_right") style.strip_inset.right = amount;
            else if(property == "strip_inset_bottom") style.strip_inset.bottom = amount;
            else if(property == "affordance_gap") style.affordance_gap = amount;
            else style.min_tab_main = amount;
            tab->SetCustomStyle(style);
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
    }
''',
    "preview complete tab appearance")

text = replace_once(
    text,
    '''            if(section_spec && title_card_spec) {
                UiTitleCard::Style style = accordion->GetStyle().header_style;
                for(const UiDesignerThemeOverrideSpec& property : section_spec->theme_overrides) {
                    const int q = node.theme_overrides.Find(property.id);
                    if(q >= 0)
                        UiDesignerApplyTitleCardThemeField(
                            style, property.adapter_field_id,
                            node.theme_overrides.GetValue(q));
                }
                header.SetCustomStyle(style);
                for(const UiDesignerPropertySpec& property : section_spec->properties)
                    if(title_card_spec->FindProperty(property.id))
                        UiDesignerPreviewFactory::Apply(
                            header, *title_card_spec, property.id,
                            node.GetProperty(property.id, property.default_value));
            }
''',
    '''            if(section_spec && title_card_spec) {
                UiTitleCard::Style style = accordion->GetStyle().header_style;
                bool has_local_style = false;
                for(const UiDesignerThemeOverrideSpec& property : section_spec->theme_overrides) {
                    const int q = node.theme_overrides.Find(property.id);
                    if(q >= 0 && node.IsThemeOverrideActive(property.id)) {
                        UiDesignerApplyTitleCardThemeField(
                            style, property.adapter_field_id,
                            node.theme_overrides.GetValue(q));
                        has_local_style = true;
                    }
                }
                if(has_local_style)
                    header.SetCustomStyle(style);
                for(const UiDesignerPropertySpec& property : section_spec->properties)
                    if(title_card_spec->FindProperty(property.id))
                        UiDesignerPreviewFactory::Apply(
                            header, *title_card_spec, property.id,
                            node.GetProperty(property.id, property.default_value));
            }
''',
    "semantic attach active overrides only")

old_section_block = '''    if(node->type == "UiAccordionSection") {
        const int owner_index = FindInstance(node->parent);
        if(owner_index < 0 || !instances_[owner_index].control) {
            stats_.rejected++;
            return UiDesignerApplyResult::Rejected;
        }
        UiAccordion *accordion = dynamic_cast<UiAccordion *>(
            instances_[owner_index].control.Get());
        if(!accordion) {
            stats_.rejected++;
            return UiDesignerApplyResult::Rejected;
        }
        int section_index = -1;
        for(int i = 0; i < instances_[owner_index].accordion_section_nodes.GetCount(); i++)
            if(instances_[owner_index].accordion_section_nodes[i] == node_id) {
                section_index = i;
                break;
            }
        if(section_index < 0 || section_index >= accordion->GetCount()) {
            stats_.rejected++;
            return UiDesignerApplyResult::Rejected;
        }
        if(property == "title" || property == "subtitle" || property == "copy") {
            const Value title = property == "title" ? value : node->GetProperty("title", "");
            const Value subtitle = property == "subtitle" ? value : node->GetProperty("subtitle", "");
            const Value copy = property == "copy" ? value : node->GetProperty("copy", "");
            accordion->SetSectionText(section_index, title, subtitle, copy);
            stats_.paint_updates++;
            stats_.live_applies++;
            Refresh();
            return UiDesignerApplyResult::AppliedPaint;
        }
        if(property == "open") {
            accordion->Open(section_index, (bool)value);
            stats_.ancestor_layouts++;
            stats_.live_applies++;
            Layout();
            Refresh();
            return UiDesignerApplyResult::AppliedAncestorLayout;
        }
        if(property == "lock") {
            const String lock = AsString(value);
            accordion->SetLockMode(section_index,
                lock == "Open" ? UiAccordion::Lock::Open :
                lock == "Closed" ? UiAccordion::Lock::Closed :
                UiAccordion::Lock::None);
            stats_.live_applies++;
            Layout();
            Refresh();
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
        UiTitleCard& header = accordion->GetSectionHeader(section_index);
        const UiDesignerControlSpec* title_card_spec = catalog_->Find("UiTitleCard");
        if(kind == UiDesignerTransientValueKind::ThemeOverride) {
            const UiDesignerThemeOverrideSpec* override_spec = spec->FindThemeOverride(property);
            if(!override_spec) {
                stats_.rejected++;
                return UiDesignerApplyResult::Rejected;
            }
            UiTitleCard::Style style = accordion->GetStyle().header_style;
            for(const UiDesignerThemeOverrideSpec& candidate : spec->theme_overrides) {
                const int q = node->theme_overrides.Find(candidate.id);
                if(q < 0 && candidate.id != property)
                    continue;
                const Value canonical = candidate.id == property ? value
                    : node->theme_overrides.GetValue(q);
                const Value effective = overlay_
                    ? overlay_->Resolve(node_id, UiDesignerTransientValueKind::ThemeOverride,
                                        candidate.id, canonical)
                    : canonical;
                UiDesignerApplyTitleCardThemeField(
                    style, candidate.adapter_field_id, effective);
            }
            header.SetCustomStyle(style);
            stats_.live_applies++;
            stats_.paint_updates++;
            Layout();
            Refresh();
            return UiDesignerApplyResult::AppliedAncestorLayout;
        }
        if(title_card_spec && title_card_spec->FindProperty(property)) {
            const UiDesignerApplyResult result = UiDesignerPreviewFactory::Apply(
                header, *title_card_spec, property, value);
            stats_.live_applies++;
            Layout();
            Refresh();
            return result;
        }
        stats_.rejected++;
        return UiDesignerApplyResult::Rejected;
    }
'''
new_section_block = '''    if(node->type == "UiAccordionSection") {
        const int owner_index = FindInstance(node->parent);
        if(owner_index < 0 || !instances_[owner_index].control) {
            stats_.rejected++;
            return UiDesignerApplyResult::Rejected;
        }
        UiAccordion *accordion = dynamic_cast<UiAccordion *>(
            instances_[owner_index].control.Get());
        if(!accordion) {
            stats_.rejected++;
            return UiDesignerApplyResult::Rejected;
        }
        int section_index = -1;
        for(int i = 0; i < instances_[owner_index].accordion_section_nodes.GetCount(); i++)
            if(instances_[owner_index].accordion_section_nodes[i] == node_id) {
                section_index = i;
                break;
            }
        if(section_index < 0 || section_index >= accordion->GetCount()) {
            stats_.rejected++;
            return UiDesignerApplyResult::Rejected;
        }

        UiTitleCard& header = accordion->GetSectionHeader(section_index);
        const UiDesignerControlSpec* title_card_spec = catalog_->Find("UiTitleCard");
        const auto ApplyHeaderPresentation = [&] {
            if(!title_card_spec)
                return;
            for(const UiDesignerPropertySpec& candidate : spec->properties)
                if(title_card_spec->FindProperty(candidate.id))
                    UiDesignerPreviewFactory::Apply(
                        header, *title_card_spec, candidate.id,
                        Effective(*node, candidate.id, candidate.default_value));
        };

        if(property == "title" || property == "subtitle" || property == "copy") {
            const Value title = property == "title" ? value : node->GetProperty("title", "");
            const Value subtitle = property == "subtitle" ? value : node->GetProperty("subtitle", "");
            const Value copy = property == "copy" ? value : node->GetProperty("copy", "");
            accordion->SetSectionText(section_index, title, subtitle, copy);
            ApplyHeaderPresentation();
            stats_.paint_updates++;
            stats_.live_applies++;
            Refresh();
            return UiDesignerApplyResult::AppliedPaint;
        }
        if(property == "open") {
            accordion->Open(section_index, (bool)value);
            ApplyHeaderPresentation();
            stats_.ancestor_layouts++;
            stats_.live_applies++;
            Layout();
            Refresh();
            return UiDesignerApplyResult::AppliedAncestorLayout;
        }
        if(property == "lock") {
            const String lock = AsString(value);
            accordion->SetLockMode(section_index,
                lock == "Open" ? UiAccordion::Lock::Open :
                lock == "Closed" ? UiAccordion::Lock::Closed :
                UiAccordion::Lock::None);
            ApplyHeaderPresentation();
            stats_.live_applies++;
            Layout();
            Refresh();
            return UiDesignerApplyResult::AppliedLocalLayout;
        }
        if(kind == UiDesignerTransientValueKind::ThemeOverride) {
            const UiDesignerThemeOverrideSpec* override_spec = spec->FindThemeOverride(property);
            if(!override_spec) {
                stats_.rejected++;
                return UiDesignerApplyResult::Rejected;
            }
            UiTitleCard::Style style = accordion->GetStyle().header_style;
            for(const UiDesignerThemeOverrideSpec& candidate : spec->theme_overrides) {
                if(!node->IsThemeOverrideActive(candidate.id))
                    continue;
                const int q = node->theme_overrides.Find(candidate.id);
                if(q < 0)
                    continue;
                const Value canonical = candidate.id == property ? value
                    : node->theme_overrides.GetValue(q);
                const Value effective = overlay_
                    ? overlay_->Resolve(node_id, UiDesignerTransientValueKind::ThemeOverride,
                                        candidate.id, canonical)
                    : canonical;
                UiDesignerApplyTitleCardThemeField(
                    style, candidate.adapter_field_id, effective);
            }
            header.SetCustomStyle(style);
            ApplyHeaderPresentation();
            stats_.live_applies++;
            stats_.paint_updates++;
            Layout();
            Refresh();
            return UiDesignerApplyResult::AppliedAncestorLayout;
        }
        if(title_card_spec && title_card_spec->FindProperty(property)) {
            const UiDesignerApplyResult result = UiDesignerPreviewFactory::Apply(
                header, *title_card_spec, property, value);
            stats_.live_applies++;
            Layout();
            Refresh();
            return result;
        }
        stats_.rejected++;
        return UiDesignerApplyResult::Rejected;
    }
'''
text = replace_once(text, old_section_block, new_section_block,
                    "semantic section live-apply contract")
write(rel, text)

# ---------------------------------------------------------------------------
# Code generation: do not erase default glyphs, emit complete Tab appearance,
# and apply section style/state before its final header presentation.
# ---------------------------------------------------------------------------
rel = "Utilities/UiDesigner/CodeGen/UiDesignerCodeGen.cpp"
text = read(rel)

old_glyph = '''        out << "\\t" << member << ".SetChevronGlyphs("
            << EmitCatalogIcon(AsString(Effective("chevron_open_icon", "None"))) << ", "
            << EmitCatalogIcon(AsString(Effective("chevron_closed_icon", "None"))) << ", "
            << EmitCatalogIcon(AsString(Effective("chevron_lock_icon", "None"))) << ");\\n";
        out << "\\t" << member << ".SetDragSide(" << EmitAlign(AsString(Effective("drag_side", "Right"))) << ");\\n";
        out << "\\t" << member << ".SetDragGlyph(" << EmitCatalogIcon(AsString(Effective("drag_icon", "None"))) << ");\\n";
'''
new_glyph = '''        const String open_glyph = AsString(Effective("chevron_open_icon", "Default"));
        const String closed_glyph = AsString(Effective("chevron_closed_icon", "Default"));
        const String lock_glyph = AsString(Effective("chevron_lock_icon", "Default"));
        if(open_glyph != "Default" || closed_glyph != "Default" ||
           lock_glyph != "Default") {
            const auto GlyphExpression = [&](const String& value,
                                             const String& field) {
                return value == "Default"
                    ? member + ".GetStyle()." + field
                    : EmitCatalogIcon(value);
            };
            out << "\\t" << member << ".SetChevronGlyphs("
                << GlyphExpression(open_glyph, "glyph_open") << ", "
                << GlyphExpression(closed_glyph, "glyph_closed") << ", "
                << GlyphExpression(lock_glyph, "glyph_lock") << ");\\n";
        }
        out << "\\t" << member << ".SetDragSide(" << EmitAlign(AsString(Effective("drag_side", "Right"))) << ");\\n";
        const String drag_glyph = AsString(Effective("drag_icon", "Default"));
        if(drag_glyph != "Default")
            out << "\\t" << member << ".SetDragGlyph("
                << EmitCatalogIcon(drag_glyph) << ");\\n";
'''
text = replace_once(text, old_glyph, new_glyph, "codegen inherited accordion glyphs")

old_tab_tail = '''        out << "\\t" << member << ".EnableCloseButtons(" << EmitValue(Effective("close_buttons", false)) << ");\\n";
        out << "\\t" << member << ".EnableDragHandles(" << EmitValue(Effective("drag_handles", false)) << ");\\n";
        out << "\\t" << member << ".EnableDragReorder(" << EmitValue(Effective("drag_reorder", false)) << ");\\n";
    }
'''
new_tab_tail = '''        out << "\\t" << member << ".EnableCloseButtons(" << EmitValue(Effective("close_buttons", false)) << ");\\n";
        out << "\\t" << member << ".EnableDragHandles(" << EmitValue(Effective("drag_handles", false)) << ");\\n";
        out << "\\t" << member << ".EnableDragReorder(" << EmitValue(Effective("drag_reorder", false)) << ");\\n";

        const String style_var = member + "_tab_layout_style";
        out << "\\tUiTab::Style " << style_var << " = " << member << ".GetStyle();\\n";
        out << "\\t" << style_var << ".tab_font.FaceName("
            << EmitValue(Effective("tab_font_face", StdFont().GetFaceName())) << ");\\n";
        out << "\\t" << style_var << ".tab_font.Height("
            << max(1, (int)Effective("tab_font_size", StdFont().GetHeight())) << ");\\n";
        out << "\\t" << style_var << ".tab_font.Bold("
            << EmitValue(Effective("tab_font_bold", StdFont().IsBold())) << ");\\n";
        out << "\\t" << style_var << ".tab_font.Italic("
            << EmitValue(Effective("tab_font_italic", StdFont().IsItalic())) << ");\\n";
        out << "\\t" << style_var << ".tab_extent = DPI("
            << max(0, (int)Effective("tab_extent", 32)) << ");\\n";
        out << "\\t" << style_var << ".item_spacing = DPI("
            << max(0, (int)Effective("item_spacing", 4)) << ");\\n";
        out << "\\t" << style_var << ".body_gap = DPI("
            << max(0, (int)Effective("body_gap", 4)) << ");\\n";
        out << "\\t" << style_var << ".content_gap = DPI("
            << max(0, (int)Effective("content_gap", 6)) << ");\\n";
        out << "\\t" << style_var << ".tab_padding = Rect(DPI("
            << max(0, (int)Effective("tab_padding_left", 10)) << "), DPI("
            << max(0, (int)Effective("tab_padding_top", 6)) << "), DPI("
            << max(0, (int)Effective("tab_padding_right", 10)) << "), DPI("
            << max(0, (int)Effective("tab_padding_bottom", 6)) << "));\\n";
        out << "\\t" << style_var << ".strip_inset = Rect(DPI("
            << max(0, (int)Effective("strip_inset_left", 0)) << "), DPI("
            << max(0, (int)Effective("strip_inset_top", 0)) << "), DPI("
            << max(0, (int)Effective("strip_inset_right", 0)) << "), DPI("
            << max(0, (int)Effective("strip_inset_bottom", 0)) << "));\\n";
        out << "\\t" << style_var << ".affordance_gap = DPI("
            << max(0, (int)Effective("affordance_gap", 4)) << ");\\n";
        out << "\\t" << style_var << ".min_tab_main = DPI("
            << max(0, (int)Effective("min_tab_main", 72)) << ");\\n";
        out << "\\t" << member << ".SetCustomStyle(" << style_var << ");\\n";
    }
'''
text = replace_once(text, old_tab_tail, new_tab_tail, "codegen complete tab appearance")

old_section_codegen = '''        if(child->type == "UiAccordionSection" && node.type == "UiAccordion") {
            out << "\\tconst int " << MemberName(*child) << "_index = "
                << parent << ".AddSection(" << CppString(title) << ", "
                << EmitValue(child->GetProperty("subtitle", String())) << ", "
                << EmitValue(child->GetProperty("copy", String())) << ", "
                << EmitValue(child->GetProperty("open", false)) << ");\\n";
            const String header = MemberName(*child) + "_header";
            out << "\\tUiTitleCard& " << header << " = " << parent
                << ".GetSectionHeader(" << MemberName(*child) << "_index);\\n";
            EmitAccordionSectionHeaderProperties(out, header, *child, *child_spec);
            if(!child->theme_overrides.IsEmpty()) {
                const String style_var = MemberName(*child) + "_header_style";
                out << "\\tUiTitleCard::Style " << style_var << " = " << parent
                    << ".GetStyle().header_style;\\n";
                for(const UiDesignerThemeOverrideSpec& property : child_spec->theme_overrides) {
                    const int q = child->theme_overrides.Find(property.id);
                    if(q >= 0)
                        UiDesignerEmitTitleCardThemeField(
                            out, style_var, property.adapter_field_id,
                            child->theme_overrides.GetValue(q));
                }
                out << "\\t" << header << ".SetCustomStyle(" << style_var << ");\\n";
            }
            const String lock = child->GetProperty("lock", "None");
            if(lock != "None")
                out << "\\t" << parent << ".SetLockMode(" << MemberName(*child)
                    << "_index, UiAccordion::Lock::" << lock << ");\\n";
            for(UiDesignerNodeId content_id : child->children) {
                const UiDesignerNode* content = document.Find(content_id);
                if(!content)
                    continue;
                const UiDesignerControlSpec* content_spec = catalog_.Find(content->type);
                if(!content_spec || content_spec->IsSemanticItem())
                    continue;
                out << "\\t" << parent << ".GetSectionContent(" << MemberName(*child)
                    << "_index).Add(" << MemberName(*content) << ".SizePos());\\n";
                EmitChildren(out, document, *content);
            }
            continue;
        }
'''
new_section_codegen = '''        if(child->type == "UiAccordionSection" && node.type == "UiAccordion") {
            out << "\\tconst int " << MemberName(*child) << "_index = "
                << parent << ".AddSection(" << CppString(title) << ", "
                << EmitValue(child->GetProperty("subtitle", String())) << ", "
                << EmitValue(child->GetProperty("copy", String())) << ", "
                << EmitValue(child->GetProperty("open", false)) << ");\\n";
            const String header = MemberName(*child) + "_header";
            out << "\\tUiTitleCard& " << header << " = " << parent
                << ".GetSectionHeader(" << MemberName(*child) << "_index);\\n";

            bool has_active_header_style = false;
            for(const UiDesignerThemeOverrideSpec& property : child_spec->theme_overrides) {
                const int q = child->theme_overrides.Find(property.id);
                if(q >= 0 && child->IsThemeOverrideActive(property.id)) {
                    has_active_header_style = true;
                    break;
                }
            }
            if(has_active_header_style) {
                const String style_var = MemberName(*child) + "_header_style";
                out << "\\tUiTitleCard::Style " << style_var << " = " << parent
                    << ".GetStyle().header_style;\\n";
                for(const UiDesignerThemeOverrideSpec& property : child_spec->theme_overrides) {
                    const int q = child->theme_overrides.Find(property.id);
                    if(q >= 0 && child->IsThemeOverrideActive(property.id))
                        UiDesignerEmitTitleCardThemeField(
                            out, style_var, property.adapter_field_id,
                            child->theme_overrides.GetValue(q));
                }
                out << "\\t" << header << ".SetCustomStyle(" << style_var << ");\\n";
            }
            const String lock = child->GetProperty("lock", "None");
            if(lock != "None")
                out << "\\t" << parent << ".SetLockMode(" << MemberName(*child)
                    << "_index, UiAccordion::Lock::" << lock << ");\\n";

            // Section media and presentation are deliberately applied last:
            // Accordion open/lock operations refresh the exposed header media.
            EmitAccordionSectionHeaderProperties(out, header, *child, *child_spec);

            for(UiDesignerNodeId content_id : child->children) {
                const UiDesignerNode* content = document.Find(content_id);
                if(!content)
                    continue;
                const UiDesignerControlSpec* content_spec = catalog_.Find(content->type);
                if(!content_spec || content_spec->IsSemanticItem())
                    continue;
                out << "\\t" << parent << ".GetSectionContent(" << MemberName(*child)
                    << "_index).Add(" << MemberName(*content) << ".SizePos());\\n";
                EmitChildren(out, document, *content);
            }
            continue;
        }
'''
text = replace_once(text, old_section_codegen, new_section_codegen,
                    "codegen semantic section ordering")
write(rel, text)

# ---------------------------------------------------------------------------
# Regression coverage.
# ---------------------------------------------------------------------------
rel = "Utilities/UiDesigner/RegressionTests/main.cpp"
text = read(rel)

test_anchor = '''    Check(section_icon && section_icon->choices.GetCount() ==
              UiIconCatalog().GetCount() + 1,
          "Icon properties enumerate the authoritative UiIcons catalogue");

    UiDesignerDocument migrated;
'''
test_insert = '''    Check(section_icon && section_icon->choices.GetCount() ==
              UiIconCatalog().GetCount() + 1,
          "Icon properties enumerate the authoritative UiIcons catalogue");

    const UiDesignerControlSpec *accordion_owner_spec =
        semantic_session.Catalog().Find("UiAccordion");
    const UiDesignerPropertySpec *open_glyph = accordion_owner_spec
        ? accordion_owner_spec->FindProperty("chevron_open_icon") : nullptr;
    Check(open_glyph && open_glyph->default_value == "Default" &&
              open_glyph->choices.GetCount() == UiIconCatalog().GetCount() + 2,
          "Accordion glyph choices preserve the control default and expose every catalogue icon");

    const UiDesignerControlSpec *tab_spec =
        semantic_session.Catalog().Find("UiTab");
    Check(tab_spec && tab_spec->FindProperty("tab_font_face") &&
              tab_spec->FindProperty("tab_extent") &&
              tab_spec->FindProperty("tab_padding_left") &&
              tab_spec->FindProperty("strip_inset_left") &&
              tab_spec->FindProperty("content_gap"),
          "UiTab exposes API-backed font, extent, padding, inset and spacing appearance");

    int content_runs = 0;
    bool in_content = false;
    if(section_spec)
        for(const UiDesignerPropertySpec& property : section_spec->properties) {
            if(property.group == "Content") {
                if(!in_content)
                    content_runs++;
                in_content = true;
            }
            else
                in_content = false;
        }
    Check(content_runs == 1,
          "Accordion section has one contiguous Content group");

    UiDesignerSession default_glyph_session;
    const UiDesignerNodeId default_accordion =
        default_glyph_session.AddControl("UiAccordion");
    Check(default_accordion != 0,
          "Default Accordion code-generation fixture is created");
    const String default_glyph_code =
        default_glyph_session.GenerateCode("DefaultGlyphFixture");
    Check(default_glyph_code.Find(".SetChevronGlyphs(") < 0 &&
              default_glyph_code.Find(".SetDragGlyph(") < 0,
          "Generated default Accordion preserves native chevron and drag glyphs");

    const String semantic_code =
        semantic_session.GenerateCode("SemanticInspectorFixture");
    Check(semantic_code.Find(".SetTabIcon(") >= 0 &&
              semantic_code.Find(".SetTabTip(") >= 0 &&
              semantic_code.Find(".SetTabClosable(") >= 0 &&
              semantic_code.Find(".SetTabDraggable(") >= 0,
          "Generated Tab pages preserve API-backed content and behaviour");
    Check(semantic_code.Find(".GetSectionHeader(") >= 0 &&
              semantic_code.Find(".SetMedia(") >= 0,
          "Generated Accordion sections author the exposed UiTitleCard header");

    UiDesignerDocument migrated;
'''
text = replace_once(text, test_anchor, test_insert, "semantic inspector regressions")
write(rel, text)

# Static self-checks.
checks = {
    "Utilities/UiDesigner/Catalog/UiDesignerInspectorCatalog.cpp": [
        "Vector<UiDesignerPropertySpec> source = pick(spec.properties);",
        '"Default", "Control default"',
        '"tab_font_face"',
        '"tab_padding_left"',
    ],
    "Utilities/UiDesigner/UiDesigner/UiDesignerWindow.cpp": [
        "identity = primary->type;",
    ],
    "Utilities/UiDesigner/Preview/UiDesignerPreview.cpp": [
        "ApplyHeaderPresentation",
        "node->IsThemeOverrideActive(candidate.id)",
        'property == "tab_font_face"',
    ],
    "Utilities/UiDesigner/CodeGen/UiDesignerCodeGen.cpp": [
        'open_glyph != "Default"',
        "has_active_header_style",
        "_tab_layout_style",
    ],
    "Utilities/UiDesigner/RegressionTests/main.cpp": [
        "Default Accordion preserves native chevron and drag glyphs",
        "one contiguous Content group",
    ],
}
for rel, needles in checks.items():
    data = read(rel)
    for needle in needles:
        if needle not in data:
            raise RuntimeError(f"{rel}: missing verification text {needle!r}")

print("UiDesigner semantic Inspector corrective migration applied.")
